/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package com.wusoft.apps.mango.view;

import java.io.IOException;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ApplicationScoped;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.wusoft.apps.mango.model.User;
import com.wusoft.apps.mango.web.HttpUtil;
import com.wusoft.apps.mango.web.WebService;

/**
 * A typical simple backing bean, that is backed to <code>helloWorld.xhtml</code>
 */
@ManagedBean(name = "userView")
@RequestScoped
public class UserView{
	
	private User user = new User();
	
	private List<User> users;
	
	private List<User> selecteUsers;
	
	private Map<String, String> userNames;
	
	private String selectedUserName;
	
	private User editableUser = new User();
	
	private boolean renderFlag;
	
	private WebService webService = new WebService();
	
	public UserView() {

	}

	
	public void register() {
		try {
			if(!webService.isUserExist(user.getUserName()) && !webService.isEmailExist(user.getEmail())) {
				webService.register(user);
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("注册成功！"));
			} else {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("输入错误！"));
			}
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("注册出错！"));
		}
	}
	
	
	public Map<String, String> getUserNames() throws IOException {
		userNames = new HashMap<String, String>();
		
		for(User user : webService.getUsers()) {
			userNames.put(user.getUserName(), user.getUserName());	
		}

		return userNames;
	}
	
	public void setUserNames(Map<String, String> userNames) {
		this.userNames = userNames;
	}


	public void deleteUsers() {
		try {
			List<String> userNames = new LinkedList<String>();
			
			for(User selecteUser : selecteUsers) {
				userNames.add(selecteUser.getUserName());
			}
			
			webService.deleteUsers(userNames);
			
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("删除成功！"));
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("注册出错！"));
		}
	}
	
	
	public void isUserExist() throws IOException {	
		if(webService.isUserExist(user.getUserName())) {
			FacesContext.getCurrentInstance().addMessage("username1", new FacesMessage("用户名已经存在"));
		}
	}
	
	public void isEmailExist() throws IOException {
		if(webService.isEmailExist(user.getEmail())) {
			FacesContext.getCurrentInstance().addMessage("email", new FacesMessage("邮件已经存在"));
		}
	}
	
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public User getEditableUser() throws IOException {
		
		return editableUser;
	}


	public void setEditableUser(User editableUser) {
		this.editableUser = editableUser;
	}

	public void onEditableUserNameChange() throws IOException {
		editableUser = webService.getUser(selectedUserName);
		renderFlag = true;
    }

	public void editUser() throws IOException {
		webService.editUser(editableUser);
		
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("用户修改成功！"));
	}
	
	public List<User> getUsers() throws IOException {
		return webService.getUsers();
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}


	public List<User> getSelecteUsers() {
		return selecteUsers;
	}


	public void setSelecteUsers(List<User> selecteUsers) {
		this.selecteUsers = selecteUsers;
	}


	public String getSelectedUserName() {
		return selectedUserName;
	}


	public void setSelectedUserName(String selectedUserName) {
		this.selectedUserName = selectedUserName;
	}


	
}
