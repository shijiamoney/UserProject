安装前提：
	需要相关环境安装有maven，支持docker和docker compose相关工具。
安装系统：
	运行如下命令即可安装全部系统。
使用系统：
	用浏览器访问 http://localhost:8080/web

