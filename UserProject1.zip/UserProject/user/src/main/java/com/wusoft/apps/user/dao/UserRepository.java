
package com.wusoft.apps.user.dao;

import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wusoft.apps.user.model.User;


public interface UserRepository extends JpaRepository<User, String> {
}