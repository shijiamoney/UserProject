
package com.wusoft.apps.mango.web;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.wusoft.apps.mango.model.User;


public class WebService {

	private static final String userHost = "microservice-gateway:8081/User";

	public List<User> getUsers() throws IOException {
		String json = new HttpUtil().getHttpContent("http://" + userHost + "/users", "UTF-8", 10000);
		return JSON.parseObject(json, new TypeReference<List<User>>() {});
	}
	
	
	public void register(User user) throws IOException {
		new HttpUtil().httpPut("http://" + userHost + "/register", JSON.toJSONString(user), 10000);
	}
	
	public User getUser(String userName) throws IOException {
		String json = new HttpUtil().getHttpContent("http://" + userHost + "/user/" + userName, "UTF-8", 10000);
		return JSON.parseObject(json, new TypeReference<User>() {});
	}

	public void editUser(User user) throws IOException {
		new HttpUtil().httpPost("http://" + userHost + "/edit", JSON.toJSONString(user), 10000);
	}
	
	public void deleteUsers(Collection<String> userNames) throws IOException {
		new HttpUtil().httpPost("http://" + userHost + "/delete", JSON.toJSONString(userNames), 10000);
	}
	
	public boolean isUserExist(String userName) throws IOException {
		String json = new HttpUtil().getHttpContent("http://" + userHost + "/isUserExist/" + userName, "UTF-8", 10000);
		return JSON.parseObject(json, new TypeReference<Boolean>() {});
	}
	
	public boolean isEmailExist(String email) throws IOException {
		String json = new HttpUtil().getHttpContent("http://" + userHost + "/isEmailExist/" + email, "UTF-8", 10000);
		return JSON.parseObject(json, new TypeReference<Boolean>() {});
	}
}
