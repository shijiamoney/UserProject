
package com.wusoft.apps.mango.web;

import java.io.IOException;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultConnectionKeepAliveStrategy;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;

public class HttpUtil {
	private CloseableHttpClient httpClient;

	public HttpUtil(final long time) {
		DefaultConnectionKeepAliveStrategy kaStrategy = new DefaultConnectionKeepAliveStrategy() {

			public long getKeepAliveDuration(HttpResponse response, HttpContext context) {
				long keepAlive = super.getKeepAliveDuration(response, context);
				if (keepAlive == -1) {
					keepAlive = time;
				}
				return keepAlive;
			}
		};
		this.httpClient = HttpClients.custom().setKeepAliveStrategy((ConnectionKeepAliveStrategy) kaStrategy).build();
	}

	public HttpUtil() {
		this.httpClient = HttpClients.createDefault();
	}

	public String getHttpContent(String url, String encoding, Integer timeout) throws IOException {
		String content;
		content = null;
		HttpGet httpGet = new HttpGet(url);
		httpGet.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0");
		if (timeout != null) {
			RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(timeout.intValue()).setConnectTimeout(timeout.intValue()).setConnectionRequestTimeout(timeout.intValue()).setCookieSpec("compatibility").build();
			httpGet.setConfig(requestConfig);
		}
		CloseableHttpResponse response = this.httpClient.execute((HttpUriRequest) httpGet);
		try {
			if (200 == response.getStatusLine().getStatusCode()) {
				HttpEntity entity = response.getEntity();
				content = encoding != null ? EntityUtils.toString((HttpEntity) entity, (String) encoding) : EntityUtils.toString((HttpEntity) entity);
			} else if (404 == response.getStatusLine().getStatusCode()) {
				String entity = null;
				return entity;
			}
		} finally {
			response.close();
		}
		return content;
	}

	public void httpPut(String url, String body, Integer timeout) throws IOException {

		HttpPut httpPut = new HttpPut(url);
		httpPut.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0");
		if (timeout != null) {
			RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(timeout.intValue()).setConnectTimeout(timeout.intValue()).setConnectionRequestTimeout(timeout.intValue()).setCookieSpec("compatibility").build();
			httpPut.setConfig(requestConfig);
		}

		StringEntity entity = new StringEntity(body, "utf-8");
		entity.setContentEncoding("utf-8");
		entity.setContentType("application/json");
		
		httpPut.setEntity(entity);
		CloseableHttpResponse response = this.httpClient.execute(httpPut);
		try {
			if (404 == response.getStatusLine().getStatusCode()) {
				throw new RuntimeException("请求异常：" + url);
			}
		} finally {
			response.close();
		}
	}
	
	
	public void httpPost(String url, String body, Integer timeout) throws IOException {

		HttpPost httpPost = new HttpPost(url);
		httpPost.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0");
		if (timeout != null) {
			RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(timeout.intValue()).setConnectTimeout(timeout.intValue()).setConnectionRequestTimeout(timeout.intValue()).setCookieSpec("compatibility").build();
			httpPost.setConfig(requestConfig);
		}
		
		StringEntity entity = new StringEntity(body, "utf-8");
		entity.setContentEncoding("utf-8");
		entity.setContentType("application/json");
		
		httpPost.setEntity(entity);
		CloseableHttpResponse response = this.httpClient.execute(httpPost);
		try {
			if (404 == response.getStatusLine().getStatusCode()) {
				throw new RuntimeException("请求异常：" + url);
			}
		} finally {
			response.close();
		}
	}
	
}