#!/usr/bin/env bash

docker-compose -f docker-compose.yml stop

mvn clean install

set -eo pipefail

modules=( microservice-discovery-eureka microservice-admin user messenger microservice-gateway web )
for module in "${modules[@]}"; do
    docker build -t "${module}:latest" ${module}
done

docker-compose -f docker-compose.yml up -d



