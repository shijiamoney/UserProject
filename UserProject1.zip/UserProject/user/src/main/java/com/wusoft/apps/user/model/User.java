package com.wusoft.apps.user.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class User implements Serializable {
	
	@Id
	@Column(length = 20)
	private String userName;
	@Column(length = 50)
	private String password;
	@Column(length = 50)
	private String email;
	
	private Boolean deleted;

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Boolean getDeleted() {
		return deleted;
	}
	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public int hashCode() {
		int hash = 0;
		return hash += this.userName != null ? this.userName.hashCode() : 0;
	}

	public boolean equals(Object object) {
		if (object.getClass() != this.getClass()) {
			return false;
		}
		User other = (User) object;
		if (this.userName == null && other.userName != null || this.userName != null && !this.userName.equals(other.userName)) {
			return false;
		}
		return true;
	}

	public String toString() {
		return this.getClass().getName() + "[userName=" + this.userName + "]";
	}
}
