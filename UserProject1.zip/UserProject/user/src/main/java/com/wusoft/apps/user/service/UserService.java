
package com.wusoft.apps.user.service;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wusoft.apps.user.cache.CacheService;
import com.wusoft.apps.user.dao.UserRepository;
import com.wusoft.apps.user.model.Email;
import com.wusoft.apps.user.model.User;

@Service
@EnableBinding(Source.class)
@Transactional
public class UserService {
	
	private static Logger logger  = LoggerFactory.getLogger(UserService.class);

	@Autowired
	private MessageChannel output;
	
	@Autowired
	private CacheService cacheService;
	
	@Autowired
	private UserRepository userRepository;
	
//	public Collection<User> getUsers() {
//		Set<User> users = new HashSet<User>();
//		
//		for(User user : userRepository.findAll()) {
//			if(user.isActive() == true) {
//				users.add(user);
//			}
//		}
//		
//		return users;
//	}
	
	public Collection<User> getUsers() {
		List<User> users = new LinkedList<User>();
		
		for(User user : cacheService.getUsers()) {
			if(user.getDeleted() == null) {
				users.add(user);
			}
		}

		return users;
	}

	public void register(User user) {		
		user.setPassword(DigestUtils.md5Hex(user.getPassword()));
		userRepository.save(user);	
		cacheService.evictUsersCache();	
		
		Email email = new Email();
		email.setTo(user.getEmail());
		email.setTitle("注册成功");
		email.setContent("尊敬的" + user.getUserName() + ",您已注册成功！");

		output.send(MessageBuilder.withPayload(email).build());
	}	
	

	public Optional<User> getUser(String userName) {		
		return userRepository.findById(userName);
	}	
	

	public void editUser(User user) {
		user.setPassword(DigestUtils.md5Hex(user.getPassword()));
		userRepository.save(user);	
		cacheService.evictUserCache(user.getUserName());
		cacheService.evictUsersCache();	
	}
	
	public boolean isUserExist(String userName) {
		Set<String> userNames = new HashSet<String>();
		
		Collection<User> users = cacheService.getUsers();
		for(User user : users) {
			userNames.add(user.getUserName());
		}
		
		return userNames.contains(userName);
	}
	
	public boolean isEmailExist(String email) {
		Set<String> emails = new HashSet<String>();
		
		Collection<User> users = cacheService.getUsers();
		for(User user : users) {
			emails.add(user.getEmail());
		}
		
		return emails.contains(email);
	}
	
	public void deleteUsers(Collection<String> userNames) {
		for(String userName : userNames) {
			Optional<User> optional = getUser(userName);
			if(optional.isPresent()) {
				User user = optional.get();
				user.setDeleted(true);
				userRepository.save(user);
			}	
		}
		
		cacheService.evictUsersCache();	
	}
	

}
