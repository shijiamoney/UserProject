package com.wusoft.apps.user.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.wusoft.apps.user.cache.CacheService;
import com.wusoft.apps.user.dao.UserRepository;
import com.wusoft.apps.user.model.User;

@SpringBootTest
@ActiveProfiles("test")
@Transactional
@WebAppConfiguration
@ContextConfiguration
public class UserServiceTest {
	
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private UserService userService;
	@Autowired
	private CacheService cacheService;
	
	@Test
	@Rollback
	public void register() {

		/*
		 * 前后注册两个用户，校验数据库里是否可查到相应数据，并查看相关缓存是否已经更新
		 */
		User user = new User();
		user.setUserName("张三");
		user.setEmail("zhangsan@outlook.com");
		user.setPassword("张三");
		user.setDeleted(false);

		userService.register(user);

		Optional<User> optional = userRepository.findById("张三");
		assertThat(optional.get()).isEqualTo(user);
		assertThat(1).isEqualTo(userRepository.findAll().size());
		assertThat(1).isEqualTo(cacheService.getUsers().size());

		User user1 = new User();
		user1.setUserName("李四");
		user1.setEmail("lisi@outlook.com");
		user1.setPassword("李四");
		user1.setDeleted(false);

		userService.register(user1);

		optional = userRepository.findById("李四");
		assertThat(optional.get()).isEqualTo(user1);
		assertThat(2).isEqualTo(userRepository.findAll().size());
		assertThat(2).isEqualTo(cacheService.getUsers().size());
	}

	@Test
	@Rollback
	public void edit() {
		/*
		 * 修改email地址，校验是否正确更新
		 */
		User user = new User();
		user.setUserName("张三");
		user.setEmail("zhangsan@outlook.com");
		user.setPassword("张三");
		user.setDeleted(false);

		userRepository.save(user);

		User user1 = new User();
		user1.setUserName("张三");
		user1.setEmail("zhangsan@hotmail.com");
		user1.setPassword("张三");
		user1.setDeleted(false);

		userService.editUser(user1);

		Optional<User> optional = userRepository.findById("张三");
		assertThat("zhangsan@hotmail.com").isEqualTo(optional.get().getEmail());
		assertThat("zhangsan@hotmail.com").isEqualTo(cacheService.getUser("张三").get().getEmail());
	}

	@Test
	@Rollback
	public void isUserExist() {
		
		User user = new User();
		user.setUserName("张三");
		user.setEmail("zhangsan@outlook.com");
		user.setPassword("张三");
		user.setDeleted(false);

		userRepository.save(user);
		
		assertThat(true).isEqualTo(userService.isUserExist("张三"));
		assertThat(false).isEqualTo(userService.isUserExist("王五"));
		
	}
	
	@Test
	@Rollback
	public void isEmailExist() {
		
		User user = new User();
		user.setUserName("张三");
		user.setEmail("zhangsan@outlook.com");
		user.setPassword("张三");
		user.setDeleted(false);

		userRepository.save(user);
		
		assertThat(true).isEqualTo(userService.isEmailExist("zhangsan@outlook.com"));
		assertThat(false).isEqualTo(userService.isEmailExist("kevin@outlook.com"));
	}
	
	
	@Test
	@Rollback
	public void deleteUsers() {

		/*
		 * 前后注册两个用户，校验数据库里是否可查到相应数据，并查看相关缓存是否已经更新
		 */
		User user = new User();
		user.setUserName("张三");
		user.setEmail("zhangsan@outlook.com");
		user.setPassword("张三");
		user.setDeleted(false);
		userRepository.save(user);


		User user1 = new User();
		user1.setUserName("李四");
		user1.setEmail("lisi@outlook.com");
		user1.setPassword("李四");
		user1.setDeleted(false);
		userRepository.save(user1);
		
		List<String> userNames = new LinkedList<String>();
		userNames.add("张三");
		userNames.add("李四");

		userService.deleteUsers(userNames);
		
		Optional<User> optional = userRepository.findById("张三");
		assertThat(true).isEqualTo(optional.get().getDeleted());
		
		optional = userRepository.findById("李四");
		assertThat(true).isEqualTo(optional.get().getDeleted());
		
	}
	
}
