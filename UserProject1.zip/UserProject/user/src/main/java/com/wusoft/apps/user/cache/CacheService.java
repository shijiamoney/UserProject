package com.wusoft.apps.user.cache;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.wusoft.apps.user.dao.UserRepository;
import com.wusoft.apps.user.model.User;
import com.wusoft.apps.user.service.UserService;

@Service
public class CacheService {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserRepository userRepository;
	
	
	@Cacheable("Users")
	public Collection<User> getUsers() {
		return userRepository.findAll();
	}
	
	@CacheEvict(value = {"Users"}, allEntries=true)
	public void evictUsersCache() {
		
	}
	
	@Cacheable(value = "User", key="#userName" )
	public Optional<User> getUser(String userName) {	
		return userService.getUser(userName);
	}
	
	@CacheEvict(value = "User", key="#userName" )
	public void evictUserCache(String userName) {	

	}
	
	
}
