package com.wusoft.apps.user.service.exception;

public class ValidationException extends RuntimeException{

	public ValidationException(String messag) {
		super(messag);
	}

}
