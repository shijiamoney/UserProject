
package com.wusoft.apps.messenger.email;

import javax.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;

@Service
public class EmailUtil {
	private static Logger logger = LoggerFactory.getLogger(EmailUtil.class);
	@Autowired
	private JavaMailSender mailSender;

	public void sendEmail(final String ad, final String title, final String body) {
		try {
			MimeMessagePreparator preparator = new MimeMessagePreparator() {

				public void prepare(MimeMessage mimeMessage) throws Exception {
					MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true);
					message.setFrom("test@shijiamoney.com");
					message.addTo(ad);
					message.setSubject(title);
					if (body != null) {
						StringBuffer content = new StringBuffer();
						content.append("<html><body>");
						content.append("<br/>");
						content.append(body);
						content.append("<br/>");
						content.append("</body></html>");
						message.setText(content.toString(), true);
					}
				}
			};
			this.mailSender.send(preparator);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
